<div class="col-md-3 left_col">
          <div class="left_col scroll-view">
            <div class="navbar nav_title" style="border: 0;">
              <a class="site_title"> <i class="material-icons">account_balance</i><span> ĐẶT MÓN</span></a>
            </div>

            <div class="clearfix"></div>

            <!-- menu profile quick info -->
            <?php
                $CI =& get_instance();
                $CI->load->model('User_model');
                $user = $CI->User_model->get_user($_SESSION['user']->id);
            ?>
            <div class="profile clearfix">
              <div class="profile_pic">
                <img src="<?=base_url()?>public/assets/images/user.png" alt="..." class="img-circle profile_img">
              </div>
              <div class="profile_info" style="text-alight:center" >    
                <h2><?=$user['firstName'].' '.$user['lastName']?></h2>
              </div>
            </div>
            <!-- /menu profile quick info -->

            <br>

            <!-- sidebar menu -->
            <div id="sidebar-menu" class="main_menu_side hidden-print main_menu">
              <div class="menu_section">
                <ul class="nav side-menu">
                  <li class=""><a href="<?=base_url()?>Order"><i class="material-icons">pan_tool</i> ĐẶT MÓN  </a>   
                  </li>
                  <li class=""><a href="<?=base_url()?>Product"><i class="material-icons">view_module</i> QL MÓN  </a>   
                  </li>
                  <li class=""><a href="<?=base_url()?>OrderBill"><i class="material-icons">list</i> QL ĐƠN HÀNG  </a>   
                  </li>
                  <li class=""><a href="<?=base_url()?>User"><i class="material-icons">accessibility</i> QL NGƯỜI DÙNG  </a>   
                  </li>
                  <!-- <li class=""><a><i class="material-icons" >assessment</i> THỐNG KÊ HỆ THỐNG  </a>   
                  </li> -->
                </ul>
              </div>
            

            </div>
            <!-- /sidebar menu -->

           
          </div>
        </div>