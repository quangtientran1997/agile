
<meta charset="UTF-8">
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
   
     <link href="https://fonts.googleapis.com/css?family=Roboto:400,700&subset=latin,cyrillic-ext" rel="stylesheet" type="text/css">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet" type="text/css">
    <link href="<?=base_url()?>public/assets/plugins/bootstrap/css/bootstrap.css" rel="stylesheet">
    <link href="<?=base_url()?>public/assets/plugins/bootstrap-select/css/bootstrap-select.css" rel="stylesheet" />
    <link href="<?=base_url()?>public/assets/plugins/node-waves/waves.css" rel="stylesheet" />
    <link href="<?=base_url()?>public/assets/plugins/animate-css/animate.css" rel="stylesheet" />
    <link href="<?=base_url()?>public/assets/plugins/jquery-datatable/skin/bootstrap/css/dataTables.bootstrap.css" rel="stylesheet">
    <link href="<?=base_url()?>public/assets/css/style.css" rel="stylesheet">
    <link href="<?=base_url()?>public/assets/css/themes/all-themes.css" rel="stylesheet" />
    <link href="<?=base_url()?>public/assets/js/sweetalert.css" rel="stylesheet" />


    <script src="<?=base_url()?>public/assets/plugins/jquery/jquery.min.js"></script>


    
<!-- Bootstrap -->
<link href="<?=base_url()?>public/layouts/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link href="<?=base_url()?>public/layouts/css/font-awesome.min.css" rel="stylesheet">
    <!-- NProgress -->
   

    <!-- Custom Theme Style -->
    <link href="<?=base_url()?>public/layouts/css/custom.css" rel="stylesheet">
 
 