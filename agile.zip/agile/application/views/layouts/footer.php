 
       
    <!-- <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script> -->
    <script src="<?=base_url()?>public/assets/plugins/bootstrap/js/bootstrap.js"></script>
    <script src="<?=base_url()?>public/assets/plugins/bootstrap-select/js/bootstrap-select.js"></script>
    <script src="<?=base_url()?>public/assets/plugins/jquery-slimscroll/jquery.slimscroll.js"></script>
    <script src="<?=base_url()?>public/assets/plugins/node-waves/waves.js"></script>
    <script src="<?=base_url()?>public/assets/plugins/jquery-inputmask/jquery.inputmask.bundle.js"></script>
    <script src="<?=base_url()?>public/assets/plugins/jquery-datatable/jquery.dataTables.js"></script>
    <script src="<?=base_url()?>public/assets/plugins/jquery-datatable/skin/bootstrap/js/dataTables.bootstrap.js"></script>
    <script src="<?=base_url()?>public/assets/plugins/jquery-datatable/extensions/export/dataTables.buttons.min.js"></script>
    <script src="<?=base_url()?>public/assets/plugins/jquery-datatable/extensions/export/buttons.flash.min.js"></script>
    <script src="<?=base_url()?>public/assets/plugins/jquery-datatable/extensions/export/jszip.min.js"></script>
    <script src="<?=base_url()?>public/assets/plugins/jquery-datatable/extensions/export/pdfmake.min.js"></script>
    <script src="<?=base_url()?>public/assets/plugins/jquery-datatable/extensions/export/vfs_fonts.js"></script>
    <script src="<?=base_url()?>public/assets/plugins/jquery-datatable/extensions/export/buttons.html5.min.js"></script>
    <script src="<?=base_url()?>public/assets/plugins/jquery-datatable/extensions/export/buttons.print.min.js"></script>
    <script src="<?=base_url()?>public/assets/js/admin.js"></script>
    <script src="<?=base_url()?>public/assets/js/main.js"></script>
    <script src="<?=base_url()?>public/assets/js/demo.js"></script>
    <script src="<?=base_url()?>public/assets/js/sweetalert.min.js"></script>
    <script src="<?=base_url()?>public/assets/plugins/bootstrap-notify/bootstrap-notify.min.js"></script>
    <script src="<?=base_url()?>public/assets/js/pages/ui/tooltips-popovers.js"></script>
    <script src="<?=base_url()?>public/assets/plugins/bootstrap-select/js/bootstrap-select.js"></script>
    <script src="<?=base_url()?>public/assets/js/common.js"></script>
    <script src="<?=base_url()?>public/assets/plugins/dropzone/dropzone.js"></script>
    
    <script src="<?=base_url()?>public/assets/js/pages/tables/jquery-datatable.js"></script>

    <script>
   
        // $(document).ajaxStart(function() {
        //     $(".page-loader-wrapper").css({"display":"block"});
        // });
        // $(document).ajaxStop(function(){
        //     $(".page-loader-wrapper").css({"display":"none"});
        // });
    </script>
     

    <!-- jQuery -->
    <!-- <script src="<?=base_url()?>public/layouts/js/jquery.min.js"></script> -->
    <!-- Bootstrap -->
    <!-- <script src="<?=base_url()?>public/layouts/js/bootstrap.min.js"></script>
    -->

    <!-- Custom Theme Scripts -->
    <script src="<?=base_url()?>public/layouts/js/custom.min.js"></script>

    

    