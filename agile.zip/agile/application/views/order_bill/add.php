
      
            <div class="row clearfix">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="card">
                        <div class="header">
                        <a class="btn btn-primary btn-raised pull-right waves-effect m-t--10" data-toggle="tooltip" data-original-title="Quay lại"  onclick=" window.history.back();">
                                <i class="material-icons">keyboard_backspace</i> 
                            </a>
                            <h2>THÊM HÓA ĐƠN</h2>
                           
                        </div>
								
                        <div class="body">
                        
                            <form id="form_advanced_validation" method="POST">
                            <div class="row">
                         

                             <div class="col-lg-4 col-md-12 col-sm-12 col-xs-12">

                                <div class="form-group form-float">
                                <label class="form-label">Tổng tiền</label>
                                    <div class="form-line">
									<input type="number" class="form-control" placeholder="Tổng tiền" name="totalPrice" required>

                                       
                                    </div>
                                </div>
							</div>

							
							<div class="col-lg-4 col-md-12 col-sm-12 col-xs-12">

								<div class="form-group form-float">
								<label class="form-label">Tình trạng</label>
									<div class="form-line">
									<input type="text" class="form-control" placeholder="Tình trạng" name="status" >

									
									</div>
								</div>
								</div>
								
								
								<div class="col-lg-4 col-md-12 col-sm-12 col-xs-12">

								<div class="form-group form-float">
								<label class="form-label">Mô tả</label>
									<div class="form-line">
									<input type="text" class="form-control" placeholder="Mô tả" name="description" >

									
									</div>
							
								</div>

								</div>
								
                            
                           
                           

							
							
                             </div>
                                <button class="btn btn-primary waves-effect btn-block" type="submit">LƯU</button>
                            </form>
                        </div>
                    </div>
                </div>
			</div>
		

           
      
   
    



												